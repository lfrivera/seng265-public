# What you think there, then?

# Free lunch, or something? Eh? Eh!

# I'm talking to **you**!





# What...

# ... you're doing to delete me?




# Hey, hang on... sorry about being such a rough talker!

# Eh? No, really?






# Oh oh....
